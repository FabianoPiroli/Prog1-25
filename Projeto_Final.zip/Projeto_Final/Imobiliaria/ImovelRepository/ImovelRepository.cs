﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelo;


namespace Repository
{
    public class ImovelRepository
    {

        public Imovel Retrieve(int id)
        {
            foreach (Imovel i in ImovelData.Imoveis)
            {
                if (i.Id == id)
                {
                    return i;
                }
            }
            return null!;
        }

        public List<Imovel> RetieveByName(string name)
        {
            List<Imovel> imoveis = new List<Imovel>();
            foreach (Imovel i in ImovelData.Imoveis)
            {
                if (i.Nome.Contains(name, StringComparison.OrdinalIgnoreCase))
                {
                    imoveis.Add(i);
                }
            }
            return imoveis;
        }

        public List<Imovel> RetrieveAll()
        {
            return ImovelData.Imoveis;
        }

        public void Save(Imovel imovel)
        {
            imovel.Id = GetCount() + 1;
            ImovelData.Imoveis.Add(imovel);
        }

        public int GetCount()
        {
            return ImovelData.Imoveis.Count;
        }

        public bool Delete(Imovel imovel)
        {
            return ImovelData.Imoveis.Remove(imovel);
        }

        public bool DeleteById(int id)
        {
            Imovel imovel = Retrieve(id);
            if (imovel != null)
            {
                return ImovelData.Imoveis.Remove(imovel);
            }
            return false;
        }

        public void Update(Imovel newImovel)
        {
            Imovel oldImovel = Retrieve(newImovel.Id);
            oldImovel.Nome = newImovel.Nome;
            oldImovel.Preco = newImovel.Preco;
            oldImovel.Quartos = newImovel.Quartos;
            oldImovel.Banheiros = newImovel.Banheiros;
            oldImovel.VagasGaragem = newImovel.VagasGaragem;
            oldImovel.Endereco = newImovel.Endereco;
            oldImovel.Descricao = newImovel.Descricao;
            oldImovel.CaminhoImagem = newImovel.CaminhoImagem;
            oldImovel.CategoriaId = newImovel.CategoriaId;
            oldImovel.Categoria = newImovel.Categoria;
        }
    }
}
